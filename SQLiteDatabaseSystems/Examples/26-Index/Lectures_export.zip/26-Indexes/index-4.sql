--SQLite

.eqp on
.timer on
.output out.res.index


select l_orderkey
from lineitem
where l_quantity >= 10
    and l_quantity <= 20;

select l_orderkey
from lineitem
where l_quantity >= 10
    and l_quantity <= 20;

select l_orderkey
from lineitem
where l_quantity >= 10
    and l_quantity <= 20;

select l_orderkey
from lineitem
where l_quantity >= 10
    and l_quantity <= 20;

select l_orderkey
from lineitem
where l_quantity >= 10
    and l_quantity <= 20;

select l_orderkey
from lineitem
where l_quantity >= 10
    and l_quantity <= 20;

select l_orderkey
from lineitem
where l_quantity >= 10
    and l_quantity <= 20;

select l_orderkey
from lineitem
where l_quantity >= 10
    and l_quantity <= 20;

select l_orderkey
from lineitem
where l_quantity >= 10
    and l_quantity <= 20;

select l_orderkey
from lineitem
where l_quantity >= 10
    and l_quantity <= 20;

select l_orderkey
from lineitem
where l_quantity >= 10
    and l_quantity <= 20;
