--SQLite

.eqp on
.timer on


insert into lineitem
    select * from lineitem;
